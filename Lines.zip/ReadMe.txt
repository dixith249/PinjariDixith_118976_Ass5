Folder 'Lines' can be executed as a python module by running "python -i Lines" from console when in it's directory. 

It can also be launched by simply running launch.bat. 

'myModule.py' inside of folder 'Lines' contains main functions bubbleSort and sweepLines. 
sort function works like this: sortedList = bubbleSort(list, comparison_function) 
sweepLines works like this: array = sweepLines(points)
points is a list of points with each 2 points forming a line
 and array is an array of intersections represented by sets with 2 lines in it

'Lines' automatically prints a test.