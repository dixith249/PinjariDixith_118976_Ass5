
from myModule import * #Module with sweepline algorithm
import random #random point generation

def randomLines(num): #Generate a list of random lines, each line is just 2 points one after another
    array = []
    for i in range(num):
        array.append(Point(random.uniform(0,100),random.uniform(0,100)))
        array.append(Point(random.uniform(0,100),random.uniform(0,100)))
    return array

points = randomLines(3)

def printSet(s): #Prints a set outputted by sweeplines algorithm, set contains 2 lines
    el = s.pop()
    print(el.x,",",el.y,"/",el.partner.x,",",el.partner.y)
    print("CROSSES")
    el2 = s.pop()
    if el2 == el.partner:
        el2 = s.pop()
    print(el2.x,",",el2.y,"/",el2.partner.x,",",el2.partner.y)
    print("---------")

array = sweepLines(points)

def naive(array): #Naive algorithm for checking
    inters = []
    for i in range(len(array)//2):
        for j in range(i+1,len(array)//2):
            if lineIntersect(array[i*2],array[i*2+1],array[j*2],array[j*2+1]):
                s = set((array[i*2],array[i*2+1],array[j*2],array[j*2+1]))
                if s not in inters:
                    inters.append(s)
    return inters

array2 = naive(points)

print("LINES:")
for i in range(len(points)//2): #print lines
    print("LINE:")
    print(points[i*2].x,",",points[i*2].y)
    print(points[i*2+1].x,",",points[i*2+1].y)
print()
print("sweeplines and naive might print points in different order")
print()
print("SWEEPLINES FOUND:")
for s in array: #print intersections of sweeplines
    printSet(s)
print("NAIVE FOUND:")
for s in array2: #print naive intersections
    printSet(s)
