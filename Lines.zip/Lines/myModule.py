

#Sort using bubble sort and a cusrom comparison function
def bubbleSort(array, func = lambda a,b: a>b):
	array = array[:] #Copy array so original one remains same
	for i in range(len(array)):
		for j in range(i+1,len(array)):
			if func(array[i],array[j]):
				array[i],array[j] = array[j],array[i]
	return array

class Node: #Nodes of a binary tree
    
    def __init__(self, key, value = None): #Constructor
        self.key = key
        self.value = value
        self.left = None
        self.right = None
        self.parent = None
    
    def insert(self, newNode): #Recursive insert new node
        if self.key > newNode.key: #smaller keys go to the left
            if self.left == None:
                self.left = newNode
                newNode.parent = self
            else:
                self.left.insert(newNode)
        else: #Equal or larger keys go the right
            if self.right == None:
                self.right = newNode
                newNode.parent = self
            else:
                self.right.insert(newNode)
    
    def get(self, toGet): #Gets a value from the tree, returns node
        if self.value == toGet:
            return self
        if self.left != None:
            found = self.left.get(toGet)
            if found != None:
                return found
        if self.right != None:
            found = self.right.get(toGet)
            if found != None:
                return found
        return None
    
    def rightmost(self): #recursively goes to the right
        if self.right != None:
            return self.right.rightmost()
        else:
            return self
    
    def leftmost(self): #Recursively goes to the left
        if self.left != None:
            return self.left.leftmost()
        else:
            return self
    
    def smaller(self): #Properly finds a node with largest of keys smaller than this node, also considering parents
        below = self.left
        if below != None:
            below = below.rightmost()
        elif self.parent != None:
            par = self
            while par.parent != None:
                par = par.parent
                if par.key < self.key:
                    if below == None or par.key > below.key:
                        below = par
            
        return below
    
    def larger(self): #Properly finds a node with smallest of keys larger than this node, also considering parents
        above = self.right
        if above != None:
            above = above.leftmost()
        elif self.parent != None:
            par = self
            while par.parent != None:
                par = par.parent
                if par.key >= self.key:
                    if above == None or par.key < above.key:
                        above = par
        return above

class Tree: #Binary tree to store nodes
    def __init__(self, root = None): #Constructor
         self.root = root
    
    def insert(self, node): #Inserting into tree
        if self.root == None:
            self.root = node
        else:
            self.root.insert(node)
    
    def get(self, toGet): #Getting node from tree
        if self.root == None:
            return None
        else:
            return self.root.get(toGet)
    
    def delete(self, node): #properly deletes a node from binary tree
        if self.root == None:
            return
        replacement = None
        if node.left != None:
            replacement = node.left.rightmost()
        elif node.right != None:
            replacement = node.right.leftmost()
        else:
            if self.root == node:
                self.root = None
            else:
                if node.parent.left == node:
                    node.parent.left = None
                elif node.parent.right == node:
                    node.parent.right = None
                node.parent = None
            return
        node.key = replacement.key
        node.value = replacement.value
        self.delete(replacement)
    

class Point: #Class representing a point
    def __init__(self, x ,y):
        self.x = x
        self.y = y
        self.partner = None #partner, with which this point forms a line
        self.isLeft = None #boolean whether this point is on the left from it's partner

def pointOnSide(p1, p2, p3): #Checks whther p3 is on the left of line p1-p2 or on the right, or lies on this line
    val = (p2.y - p1.y) * (p3.x - p2.x) - (p2.x - p1.x) * (p3.y - p2.y)
    if val > 0:
        return 1 #On the right
    elif val == 0:
        return 0 #Middle, exactly on the line
    else:
        return -1 #On the left

def between(p1,p2,p): #Checks if p lies on line p1-p2, considering that they are all parallel
    return p.x >= min(p1.x, p2.x) and p.x <= max(p1.x, p2.x) and p.y >= min(p1.y, p2.y) and p.y <= max(p1.y, p.y)

def lineIntersect(p11,p12,p21,p22): #Checks if 2 lines intersect or not, lines are p11-p12 and p21-p22
    #lines only intersect if p21 and p22 are on different sides of line p11-p12
    # and at the same time p11 and p12 are on different sides of line p21-p22
    s1 = pointOnSide(p11,p12,p21)
    if s1 == 0 and (between(p11,p12,p21)): #Also have to consider cases when a point is directly on the line
        return True
    s2 = pointOnSide(p11,p12,p22)
    if s2 == 0 and (between(p11,p12,p21)):
        return True
    s3 = pointOnSide(p21,p22,p11)
    if s3 == 0 and (between(p11,p12,p21)):
        return True
    s4 = pointOnSide(p21,p22,p12)
    if s4 == 0 and (between(p11,p12,p21)):
        return True
    
    if s1 != s2 and s3 != s4:
        return True
    
    return False

def interserctionPoint(p11,p12,p21,p22): #finds coordinates of intersection point of 2 lines p11-p12 and p21-p22
    x12 = p11.x - p12.x
    x34 = p21.x - p22.x
    y12 = p11.y - p12.y
    y34 = p21.y - p22.y
    c = x12 * y34 - y12 * x34
    a = p11.x * p12.y - p11.y * p12.x
    b = p21.x * p22.y - p21.y * p22.x
    x = (a * x34 - b * x12) / c
    y = (a * y34 - b * y12) / c
    return x,y

def insertProperly(array,point): #properly inserts a point into an array of points sorted by their X coordinate
    i = 0
    while i<len(array):
        if array[i].x >= point.x:
            array.insert(i, point)
            break
        i+=1
    else:
        array.append(point)

def updateNode(tree, node, x): #updates node position in tree with regard to Y coordinate of this line at x
    if node == None:
        return None
    p1 = node.value
    p2 = node.value.partner
    _,y = interserctionPoint(p1,p2,Point(x,0),Point(x,1))
    tree.delete(node)
    newNode = Node(y,p1)
    tree.insert(newNode)
    return newNode

def sweepLines(array): #Returns an array of intersections as sets of 4 points
    #In this function we first sort array of points by their X coordinate
    #We also remember who is point's partner and whether it is left or right point of line
    #Next we start checking points from left to right one by one, checking for intersections
    #If it is a left point, we insert it into a binary search tree with it's Y coordinate as the key
    # and check for intersections with lines directly above and directly below
    # if there is an intersection, we add this intersection as a point into the array, saving the intersecting lines into isLeft parameter
    #If it is a right point, we remove it's partner from binary search tree and check intersection of lines directly below and above
    # if there is an intersection, we add this intersection as a point into the array, saving the intersecting lines into isLeft parameter
    #If this is an intersection point, we delete both intersecting lines from the tree and insert them back
    # but we insert them both with the Y coordinate of intersection as the key
    # we also check for intersections of the lower of those 2 lines with a line above them and for intersection of the upper with a line below them
    # if there is an intersection, we add this intersection as a point into the array, saving the intersecting lines into isLeft parameter
    #The idea behind this entire algorithm is that lines only intersect with neighbouring lines,
    # and their neighbours only change when they intersect
    # so we scan lines from left to right, also checking on intersection points
    previous = None #Lines are represented by 2 points in array, 1 after another
    for point in array: #Check each point, setting it's partner and isLeft parameters
        if previous == None:
            previous = point
        else:
            previous.partner = point
            point.partner = previous
            previous = None
            
            if point.x < point.partner.x:
                point.isLeft = True
                point.partner.isLeft = False
            else:
                point.isLeft = False
                point.partner.isLeft = True
    array = bubbleSort(array,lambda a,b: a.x > b.x) #Sort array of points by their X coordinate
    intersects = [] #array of intersections
    #All insertions into this array are made after checking if intersection wasn't already there
    tree = Tree() #Binary tree, in which we will store points by their Y coordinate
    for i in range(len(array)):
         #If it is a left point, we insert it into a binary search tree with it's Y coordinate as the key
         # and check for intersections with lines directly above and directly below
        if array[i].isLeft == True:
            node = Node(array[i].y, array[i])
            tree.insert(node)
            above = node.larger()
            if above != None:
                p1 = array[i]
                p2 = array[i].partner
                p3 = above.value
                p4 = above.value.partner
                if lineIntersect(p1,p2,p3,p4):
                    newSet = set((p1,p2,p3,p4))
                    if newSet not in intersects:
                        intersects.append(newSet)
                        x,y = interserctionPoint(p1,p2,p3,p4)
                        p = Point(x,y)
                        p.isLeft = (p1, p3)
                        insertProperly(array, p)
            
            below = node.smaller()
            if below != None:
                p1 = array[i]
                p2 = array[i].partner
                p3 = below.value
                p4 = below.value.partner
                if lineIntersect(p1,p2,p3,p4):
                    newSet = set((p1,p2,p3,p4))
                    if newSet not in intersects:
                        intersects.append(newSet)
                        x,y = interserctionPoint(p1,p2,p3,p4)
                        p = Point(x,y)
                        p.isLeft = (p3, p1)
                        insertProperly(array, p)
            aboveVal = None
            if above != None:
                aboveVal = above.value
            updateNode(tree, below, array[i].x)
            updateNode(tree, tree.get(aboveVal), array[i].x)
            
        #If it is a right point, we remove it's partner from binary search tree and check intersection of lines directly below and above
        elif array[i].isLeft == False:
            node = tree.get(array[i].partner)
            above = node.larger()
            below = node.smaller()
            if above != None and below != None and above != below:
                p1 = above.value
                p2 = above.value.partner
                p3 = below.value
                p4 = below.value.partner
                if lineIntersect(p1,p2,p3,p4):
                    newSet = set((p1,p2,p3,p4))
                    if newSet not in intersects:
                        intersects.append(newSet)
                        x,y = interserctionPoint(p1,p2,p3,p4)
                        p = Point(x,y)
                        p.isLeft = (below.value, above.value)
                        insertProperly(array, p)
            aboveVal = None
            if above != None:
                aboveVal = above.value
            updateNode(tree, below, array[i].x)
            updateNode(tree, tree.get(aboveVal), array[i].x)
            
            node = tree.get(array[i].partner)
            tree.delete(node)
        #If this is an intersection point, we delete both intersecting lines from the tree and insert them back
        # but we insert them both with the Y coordinate of intersection as the key
        # we also check for intersections of the lower of those 2 lines with a line above them and for intersection of the upper with a line below them
        else:
            lower,upper = array[i].isLeft
            lower = tree.get(lower)
            upper = tree.get(upper)
            above = upper.larger()
            below = lower.smaller()
            aboveVal = None
            if above != None:
                aboveVal = above.value
            belowVal = None
            if below != None:
                belowVal = below.value
            if above != None and above != lower:
                p1 = above.value
                p2 = above.value.partner
                p3 = lower.value
                p4 = lower.value.partner
                if lineIntersect(p1,p2,p3,p4):
                    newSet = set((p1,p2,p3,p4))
                    if newSet not in intersects:
                        intersects.append(newSet)
                        x,y = interserctionPoint(p1,p2,p3,p4)
                        p = Point(x,y)
                        p.isLeft = (lower.value, above.value)
                        insertProperly(array, p)
            if below != None and below != upper:
                p1 = upper.value
                p2 = upper.value.partner
                p3 = below.value
                p4 = below.value.partner
                if lineIntersect(p1,p2,p3,p4):
                    newSet = set((p1,p2,p3,p4))
                    if newSet not in intersects:
                        intersects.append(newSet)
                        x,y = interserctionPoint(p1,p2,p3,p4)
                        p = Point(x,y)
                        p.isLeft = (below.value, upper.value)
                        insertProperly(array, p)
            newLower = Node(array[i].y,lower.value)
            newUpper = Node(array[i].y,upper.value)
            tree.delete(upper)
            lower = tree.get(newLower.value)
            tree.delete(lower)
            tree.insert(newUpper)
            tree.insert(newLower)
            
            updateNode(tree, tree.get(belowVal), array[i].x)
            updateNode(tree, tree.get(aboveVal), array[i].x)
            
    return intersects #Array of sets of intersecting points


